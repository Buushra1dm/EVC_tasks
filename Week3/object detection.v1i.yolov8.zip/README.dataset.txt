# object detection > 2024-07-16 9:37am
https://universe.roboflow.com/objectdetection-k0gbh/object-detection-nq6c6

Provided by a Roboflow user
License: CC BY 4.0

